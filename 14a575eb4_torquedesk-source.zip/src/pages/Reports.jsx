import React, { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { base44 } from '@/api/base44Client';
import PageHeader from '@/components/PageHeader';
import StatCard from '@/components/StatCard';
import ErrorPanel from '@/components/ErrorPanel';
import { Button } from '@/components/ui/button';
import { compactCurrency, currency, monthLabel } from '@/lib/format';

const tooltipStyle = {
  borderRadius: 12,
  border: '1px solid hsl(var(--border))',
  background: 'hsl(var(--card))',
  fontSize: 12,
};

function Breakdown({ title, note, rows }) {
  const max = Math.max(...rows.map((r) => r.value), 1);
  return (
    <div className="panel p-5">
      <div className="flex items-baseline justify-between">
        <h2 className="font-display text-base font-semibold tracking-tight">{title}</h2>
        {note && <span className="text-xs text-muted-foreground">{note}</span>}
      </div>
      <ul className="mt-5 space-y-4">
        {rows.map((row) => (
          <li key={row.label}>
            <div className="flex items-baseline justify-between gap-3 text-sm">
              <span className="truncate text-foreground">{row.label}</span>
              <span className="shrink-0 font-semibold text-foreground">{currency(row.value)}</span>
            </div>
            <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-secondary">
              <div
                className="h-full rounded-full bg-primary"
                style={{ width: `${Math.max((row.value / max) * 100, 3)}%` }}
              />
            </div>
            {row.meta && <p className="mt-1.5 text-[11px] text-muted-foreground">{row.meta}</p>}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default function Reports() {
  const [data, setData] = useState(null);
  const [failed, setFailed] = useState(false);

  const load = useCallback(async () => {
    setFailed(false);
    try {
      const [monthly, byType, byTech, byCustomer, byPay] = await Promise.all([
        base44.entities.ServiceRecord.aggregate({
          dateBucket: { field: 'service_date', unit: 'month' },
          sum: ['total_cost', 'labor_cost', 'parts_cost'],
        }),
        base44.entities.ServiceRecord.aggregate({
          groupBy: 'service_type',
          sum: ['total_cost'],
        }),
        base44.entities.ServiceRecord.aggregate({
          groupBy: 'technician',
          sum: ['total_cost'],
        }),
        base44.entities.ServiceRecord.aggregate({
          groupBy: 'customer_name',
          sum: ['total_cost'],
          sort: '-sum_total_cost',
          limit: 8,
        }),
        base44.entities.ServiceRecord.aggregate({
          groupBy: 'payment_status',
          sum: ['total_cost'],
        }),
      ]);

      const months = (monthly.rows ?? [])
        .map((r) => ({
          key: r.service_date,
          month: monthLabel(r.service_date),
          labour: r.sum_labor_cost || 0,
          parts: r.sum_parts_cost || 0,
          total: r.sum_total_cost || 0,
          jobs: r.count || 0,
        }))
        .sort((a, b) => String(a.key).localeCompare(String(b.key)))
        .slice(-8);

      const revenue = months.reduce((sum, m) => sum + m.total, 0);
      const paid = (byPay.rows ?? []).find((r) => r.payment_status === 'paid')?.sum_total_cost || 0;
      const unpaid = (byPay.rows ?? []).find((r) => r.payment_status === 'unpaid')?.sum_total_cost || 0;

      setData({
        months,
        revenue,
        paid,
        unpaid,
        types: (byType.rows ?? [])
          .map((r) => ({ label: r.service_type || 'Unspecified', value: r.sum_total_cost || 0, meta: `${r.count} jobs` }))
          .sort((a, b) => b.value - a.value),
        techs: (byTech.rows ?? [])
          .map((r) => ({ label: r.technician || 'Unassigned', value: r.sum_total_cost || 0, meta: `${r.count} jobs handled` }))
          .filter((r) => r.value > 0)
          .sort((a, b) => b.value - a.value),
        customers: (byCustomer.rows ?? []).map((r) => ({
          name: r.customer_name || 'Unknown',
          jobs: r.count || 0,
          total: r.sum_total_cost || 0,
        })),
      });
    } catch (error) {
      setFailed(true);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const header = (
    <PageHeader
      eyebrow="Results"
      title="Reports"
      description="Revenue, service mix and payment position across the workshop."
      actions={
        <Button asChild variant="outline">
          <Link to="/services">Back to jobs</Link>
        </Button>
      }
    />
  );

  if (failed) {
    return (
      <div className="space-y-7">
        {header}
        <ErrorPanel message="The report totals did not load." onRetry={load} />
      </div>
    );
  }

  if (!data) {
    return (
      <div className="space-y-7">
        {header}
        <div className="panel px-5 py-20 text-center text-sm text-muted-foreground">
          Crunching the numbers…
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-7">
      {header}

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Total service value" value={currency(data.revenue)} tone="green" />
        <StatCard label="Collected" value={currency(data.paid)} tone="blue" />
        <StatCard
          label="Outstanding"
          value={currency(data.unpaid)}
          hint={data.revenue ? `${Math.round((data.unpaid / data.revenue) * 100)}% of billed work` : ''}
          tone="amber"
        />
        <StatCard
          label="Jobs reported"
          value={data.months.reduce((sum, m) => sum + m.jobs, 0)}
          tone="ink"
        />
      </div>

      <div className="panel p-5">
        <div className="flex items-baseline justify-between">
          <h2 className="font-display text-base font-semibold tracking-tight">
            Labour vs parts by month
          </h2>
          <span className="text-xs text-muted-foreground">Last {data.months.length} months</span>
        </div>
        <div className="mt-5 h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data.months} margin={{ top: 4, right: 8, left: 0, bottom: 0 }}>
              <CartesianGrid vertical={false} stroke="hsl(var(--border))" strokeDasharray="3 3" />
              <XAxis
                dataKey="month"
                tickLine={false}
                axisLine={false}
                tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
              />
              <YAxis
                tickLine={false}
                axisLine={false}
                width={58}
                tickFormatter={compactCurrency}
                tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
              />
              <Tooltip
                contentStyle={tooltipStyle}
                formatter={(value, name) => [currency(value), name]}
                cursor={{ fill: 'hsl(var(--secondary))' }}
              />
              <Bar dataKey="labour" name="Labour" stackId="cost" fill="hsl(var(--chart-1))" maxBarSize={46} />
              <Bar
                dataKey="parts"
                name="Parts"
                stackId="cost"
                fill="hsl(var(--chart-2))"
                radius={[6, 6, 0, 0]}
                maxBarSize={46}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Breakdown title="Revenue by service type" note="All jobs" rows={data.types.slice(0, 6)} />
        <Breakdown title="Technician workload" note="Value of jobs handled" rows={data.techs.slice(0, 6)} />
      </div>

      <div className="panel overflow-hidden">
        <div className="border-b border-border px-5 py-4">
          <h2 className="font-display text-base font-semibold tracking-tight">Top customers</h2>
        </div>
        {data.customers.length === 0 ? (
          <p className="px-5 py-10 text-center text-sm text-muted-foreground">
            No service jobs recorded yet.
          </p>
        ) : (
          <div>
            <div className="hidden grid-cols-12 gap-4 border-b border-border px-5 py-3 text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground sm:grid">
              <span className="sm:col-span-6">Customer</span>
              <span className="sm:col-span-2 text-right">Jobs</span>
              <span className="sm:col-span-2 text-right">Total spend</span>
              <span className="sm:col-span-2 text-right">Average job</span>
            </div>
            {data.customers.map((row) => (
              <div
                key={row.name}
                className="grid grid-cols-1 gap-2 border-b border-border px-5 py-3.5 text-sm last:border-0 hover:bg-secondary/40 sm:grid-cols-12 sm:items-center sm:gap-4"
              >
                <span className="font-medium text-foreground sm:col-span-6">{row.name}</span>
                <span className="text-muted-foreground sm:col-span-2 sm:text-right">{row.jobs}</span>
                <span className="font-semibold text-foreground sm:col-span-2 sm:text-right">
                  {currency(row.total)}
                </span>
                <span className="text-muted-foreground sm:col-span-2 sm:text-right">
                  {currency(row.jobs ? row.total / row.jobs : 0)}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}