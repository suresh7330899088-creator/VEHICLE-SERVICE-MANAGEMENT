import React, { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Car, MapPin, Pencil, Phone, Plus, Search, Trash2, Users } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import PageHeader from '@/components/PageHeader';
import EmptyState from '@/components/EmptyState';
import ConfirmDialog from '@/components/ConfirmDialog';
import CustomerForm from '@/components/customers/CustomerForm';
import useCurrentUser from '@/hooks/useCurrentUser';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

export default function Customers() {
  const user = useCurrentUser();
  const isAdmin = user?.role === 'admin';

  const [search, setSearch] = useState('');
  const [term, setTerm] = useState('');
  const [rows, setRows] = useState([]);
  const [counts, setCounts] = useState({});
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setTerm(search.trim()), 300);
    return () => clearTimeout(t);
  }, [search]);

  const load = useCallback(async () => {
    setLoading(true);
    const query = {};
    if (term) {
      query.$or = [
        { full_name: { $regex: term, $options: 'i' } },
        { phone: { $regex: term, $options: 'i' } },
        { email: { $regex: term, $options: 'i' } },
        { city: { $regex: term, $options: 'i' } },
      ];
    }
    const [page, count, vehicleCounts] = await Promise.all([
      base44.entities.Customer.filter(query, { sort: 'full_name', limit: 50 }),
      base44.entities.Customer.count(query),
      base44.entities.Vehicle.aggregate({ groupBy: 'customer_id' }),
    ]);
    setRows(page.items ?? []);
    setTotal(count ?? 0);
    setCounts(
      Object.fromEntries((vehicleCounts.rows ?? []).map((r) => [r.customer_id, r.count])),
    );
    setLoading(false);
  }, [term]);

  useEffect(() => {
    load();
  }, [load]);

  const save = async (payload) => {
    setSaving(true);
    if (editing) await base44.entities.Customer.update(editing.id, payload);
    else await base44.entities.Customer.create(payload);
    setSaving(false);
    setDialogOpen(false);
    setEditing(null);
    load();
  };

  const remove = async (customer) => {
    await base44.entities.Customer.delete(customer.id);
    load();
  };

  return (
    <div className="space-y-7">
      <PageHeader
        eyebrow="Client book"
        title="Customers"
        description="Everyone who brings a vehicle in, with their contact details and fleet."
        actions={
          <Button
            onClick={() => {
              setEditing(null);
              setDialogOpen(true);
            }}
          >
            <Plus className="h-4 w-4" /> Add customer
          </Button>
        }
      />

      <div className="panel flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative w-full sm:max-w-sm">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search name, phone, email or city"
            className="pl-9"
          />
        </div>
        <p className="text-xs text-muted-foreground">
          {total} {total === 1 ? 'customer' : 'customers'} on record
        </p>
      </div>

      {loading ? (
        <div className="panel px-5 py-16 text-center text-sm text-muted-foreground">
          Loading customers…
        </div>
      ) : rows.length === 0 ? (
        <EmptyState
          icon={Users}
          title="No customers found"
          description="Add your first customer, or clear the search to see the whole client book."
        >
          <Button variant="outline" onClick={() => setSearch('')}>
            Clear search
          </Button>
        </EmptyState>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {rows.map((customer) => (
            <div key={customer.id} className="panel flex flex-col p-5">
              <div className="flex items-start justify-between gap-3">
                <Link
                  to={`/customers/${customer.id}`}
                  className="font-display text-base font-semibold text-foreground hover:text-primary"
                >
                  {customer.full_name}
                </Link>
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    title="Edit customer"
                    onClick={() => {
                      setEditing(customer);
                      setDialogOpen(true);
                    }}
                    className="rounded-lg p-2 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
                  >
                    <Pencil className="h-4 w-4" />
                  </button>
                  {isAdmin && (
                    <ConfirmDialog
                      title="Remove this customer?"
                      description="The customer record is deleted. Their vehicles and service jobs stay in the system."
                      confirmLabel="Remove customer"
                      onConfirm={() => remove(customer)}
                      trigger={
                        <button
                          type="button"
                          title="Delete customer"
                          className="rounded-lg p-2 text-muted-foreground transition-colors hover:bg-rose-50 hover:text-rose-600"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      }
                    />
                  )}
                </div>
              </div>

              <div className="mt-3 space-y-2 text-sm text-muted-foreground">
                {customer.phone && (
                  <p className="inline-flex items-center gap-2">
                    <Phone className="h-3.5 w-3.5" /> {customer.phone}
                  </p>
                )}
                {customer.city && (
                  <p className="inline-flex items-center gap-2">
                    <MapPin className="h-3.5 w-3.5" /> {customer.city}
                  </p>
                )}
              </div>

              <div className="mt-4 flex items-center gap-2 border-t border-border pt-4">
                <Car className="h-4 w-4 text-primary" />
                <span className="text-sm font-medium text-foreground">
                  {counts[customer.id] || 0}{' '}
                  {counts[customer.id] === 1 ? 'vehicle' : 'vehicles'}
                </span>
                <Link
                  to={`/customers/${customer.id}`}
                  className="ml-auto text-xs font-semibold text-primary hover:underline"
                >
                  Open record
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog
        open={dialogOpen}
        onOpenChange={(open) => {
          setDialogOpen(open);
          if (!open) setEditing(null);
        }}
      >
        <DialogContent className="max-h-[90vh] max-w-xl overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-display">
              {editing ? 'Edit customer' : 'Add customer'}
            </DialogTitle>
            <DialogDescription>
              Keep contact details handy so you can reach them about a job in progress.
            </DialogDescription>
          </DialogHeader>
          <CustomerForm
            key={editing?.id || 'new'}
            initial={editing}
            onSubmit={save}
            onCancel={() => {
              setDialogOpen(false);
              setEditing(null);
            }}
            saving={saving}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}