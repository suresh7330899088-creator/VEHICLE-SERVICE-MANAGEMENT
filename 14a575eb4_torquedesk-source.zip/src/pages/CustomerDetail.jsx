import React, { useCallback, useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Car, Mail, MapPin, Pencil, Phone, Trash2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import StatCard from '@/components/StatCard';
import EmptyState from '@/components/EmptyState';
import ConfirmDialog from '@/components/ConfirmDialog';
import CustomerForm from '@/components/customers/CustomerForm';
import ServiceHistoryList from '@/components/services/ServiceHistoryList';
import useCurrentUser from '@/hooks/useCurrentUser';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { currency } from '@/lib/format';

export default function CustomerDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const user = useCurrentUser();
  const isAdmin = user?.role === 'admin';

  const [customer, setCustomer] = useState(null);
  const [vehicles, setVehicles] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [spend, setSpend] = useState({ total: 0, unpaid: 0 });
  const [loading, setLoading] = useState(true);
  const [missing, setMissing] = useState(false);
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    let record;
    try {
      record = await base44.entities.Customer.get(id);
    } catch (error) {
      setMissing(true);
      setLoading(false);
      return;
    }
    setCustomer(record);
    setLoading(false);

    const [vehicleResult, jobResult, aggResult] = await Promise.allSettled([
      base44.entities.Vehicle.filter({ customer_id: id }, { sort: 'license_plate', limit: 50 }),
      base44.entities.ServiceRecord.filter({ customer_id: id }, { sort: '-service_date', limit: 50 }),
      base44.entities.ServiceRecord.aggregate({
        query: { customer_id: id },
        groupBy: 'payment_status',
        sum: ['total_cost'],
      }),
    ]);
    if (vehicleResult.status === 'fulfilled') setVehicles(vehicleResult.value.items ?? []);
    if (jobResult.status === 'fulfilled') setJobs(jobResult.value.items ?? []);
    if (aggResult.status === 'fulfilled') {
      const rows = aggResult.value.rows ?? [];
      setSpend({
        total: rows.reduce((sum, r) => sum + (r.sum_total_cost || 0), 0),
        unpaid: rows.find((r) => r.payment_status === 'unpaid')?.sum_total_cost || 0,
      });
    }
  }, [id]);

  useEffect(() => {
    load();
  }, [load]);

  const save = async (payload) => {
    setSaving(true);
    await base44.entities.Customer.update(id, payload);
    setSaving(false);
    setEditing(false);
    load();
  };

  const remove = async () => {
    await base44.entities.Customer.delete(id);
    navigate('/customers');
  };

  if (loading) {
    return <div className="panel px-5 py-16 text-center text-sm text-muted-foreground">Loading customer…</div>;
  }

  if (missing || !customer) {
    return (
      <EmptyState
        icon={Car}
        title="Customer not found"
        description="This record may have been removed."
      >
        <Button variant="outline" onClick={() => navigate('/customers')}>
          Back to customers
        </Button>
      </EmptyState>
    );
  }

  return (
    <div className="space-y-7">
      <Link
        to="/customers"
        className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.14em] text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="h-3.5 w-3.5" /> All customers
      </Link>

      <div className="panel p-6">
        <div className="flex flex-col gap-5 sm:flex-row sm:items-start sm:justify-between">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-primary">
              Customer record
            </p>
            <h1 className="mt-1.5 font-display text-2xl font-semibold tracking-tight">
              {customer.full_name}
            </h1>
            <div className="mt-3 flex flex-wrap gap-x-5 gap-y-2 text-sm text-muted-foreground">
              {customer.phone && (
                <span className="inline-flex items-center gap-2">
                  <Phone className="h-3.5 w-3.5" /> {customer.phone}
                </span>
              )}
              {customer.email && (
                <span className="inline-flex items-center gap-2">
                  <Mail className="h-3.5 w-3.5" /> {customer.email}
                </span>
              )}
              {customer.city && (
                <span className="inline-flex items-center gap-2">
                  <MapPin className="h-3.5 w-3.5" /> {customer.city}
                </span>
              )}
            </div>
            {customer.address && (
              <p className="mt-3 max-w-md text-sm text-muted-foreground">{customer.address}</p>
            )}
          </div>

          <div className="flex items-center gap-2">
            <Button variant="outline" onClick={() => setEditing(true)}>
              <Pencil className="h-4 w-4" /> Edit
            </Button>
            {isAdmin && (
              <ConfirmDialog
                title="Remove this customer?"
                description="Their vehicles and service jobs stay in the system, but the customer record is deleted."
                confirmLabel="Remove customer"
                onConfirm={remove}
                trigger={
                  <Button variant="outline" className="text-rose-600 hover:text-rose-700">
                    <Trash2 className="h-4 w-4" /> Delete
                  </Button>
                }
              />
            )}
          </div>
        </div>

        {customer.notes && (
          <p className="mt-5 rounded-xl bg-secondary px-4 py-3 text-sm text-muted-foreground">
            {customer.notes}
          </p>
        )}
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Vehicles" value={vehicles.length} icon={Car} tone="ink" />
        <StatCard label="Service jobs" value={jobs.length} tone="blue" />
        <StatCard label="Lifetime spend" value={currency(spend.total)} tone="green" />
        <StatCard
          label="Outstanding"
          value={currency(spend.unpaid)}
          hint={spend.unpaid > 0 ? 'Awaiting payment' : 'All settled'}
          tone="amber"
        />
      </div>

      <section className="space-y-4">
        <h2 className="font-display text-lg font-semibold tracking-tight">Vehicles</h2>
        {vehicles.length === 0 ? (
          <EmptyState
            icon={Car}
            title="No vehicles linked"
            description="Add a vehicle from the Vehicles page and pick this customer as the owner."
          />
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
            {vehicles.map((vehicle) => (
              <Link
                key={vehicle.id}
                to={`/vehicles/${vehicle.id}`}
                className="panel block p-5 transition-shadow hover:shadow-[0_1px_2px_rgba(16,20,28,0.04),0_18px_40px_-26px_rgba(16,20,28,0.4)]"
              >
                <p className="font-display text-sm font-semibold">
                  {vehicle.make} {vehicle.model}
                </p>
                <p className="mt-1 font-mono text-[11px] font-semibold tracking-wide text-muted-foreground">
                  {vehicle.license_plate}
                </p>
                <p className="mt-3 text-xs capitalize text-muted-foreground">
                  {vehicle.fuel_type} · {vehicle.year || '—'} ·{' '}
                  {vehicle.mileage ? `${vehicle.mileage.toLocaleString('en-IN')} km` : '—'}
                </p>
              </Link>
            ))}
          </div>
        )}
      </section>

      <section className="space-y-4">
        <h2 className="font-display text-lg font-semibold tracking-tight">Service history</h2>
        <ServiceHistoryList records={jobs} showVehicle />
      </section>

      <Dialog open={editing} onOpenChange={setEditing}>
        <DialogContent className="max-h-[90vh] max-w-xl overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-display">Edit customer</DialogTitle>
            <DialogDescription>Update contact details for {customer.full_name}.</DialogDescription>
          </DialogHeader>
          <CustomerForm initial={customer} onSubmit={save} onCancel={() => setEditing(false)} saving={saving} />
        </DialogContent>
      </Dialog>
    </div>
  );
}