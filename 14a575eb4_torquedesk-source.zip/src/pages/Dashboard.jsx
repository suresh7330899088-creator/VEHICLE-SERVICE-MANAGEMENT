import React, { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Car, Users, Wallet, Wrench } from 'lucide-react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { base44 } from '@/api/base44Client';
import PageHeader from '@/components/PageHeader';
import StatCard from '@/components/StatCard';
import StatusBadge from '@/components/StatusBadge';
import EmptyState from '@/components/EmptyState';
import ErrorPanel from '@/components/ErrorPanel';
import { Button } from '@/components/ui/button';
import { compactCurrency, currency, formatDate, monthLabel } from '@/lib/format';

const STATUS_META = [
  { key: 'completed', label: 'Completed', color: 'hsl(var(--chart-3))' },
  { key: 'in_progress', label: 'In progress', color: 'hsl(var(--chart-4))' },
  { key: 'scheduled', label: 'Scheduled', color: 'hsl(var(--chart-2))' },
  { key: 'cancelled', label: 'Cancelled', color: 'hsl(var(--chart-5))' },
];

const tooltipStyle = {
  borderRadius: 12,
  border: '1px solid hsl(var(--border))',
  background: 'hsl(var(--card))',
  fontSize: 12,
};

export default function Dashboard() {
  const [data, setData] = useState(null);
  const [failed, setFailed] = useState(false);

  const load = useCallback(async () => {
    setFailed(false);
    try {
      const [statusRows, monthlyRows, vehicleCount, customerCount, recentPage, unpaidRows] =
        await Promise.all([
          base44.entities.ServiceRecord.aggregate({ groupBy: 'status' }),
          base44.entities.ServiceRecord.aggregate({
            dateBucket: { field: 'service_date', unit: 'month' },
            sum: ['total_cost'],
          }),
          base44.entities.Vehicle.count(),
          base44.entities.Customer.count(),
          base44.entities.ServiceRecord.filter({}, { sort: '-service_date', limit: 6 }),
          base44.entities.ServiceRecord.aggregate({
            query: { payment_status: 'unpaid' },
            groupBy: 'payment_status',
            sum: ['total_cost'],
          }),
        ]);

      const status = Object.fromEntries((statusRows.rows ?? []).map((r) => [r.status, r.count]));
      const months = (monthlyRows.rows ?? [])
        .map((r) => ({
          key: r.service_date,
          month: monthLabel(r.service_date),
          revenue: r.sum_total_cost || 0,
          jobs: r.count || 0,
        }))
        .sort((a, b) => String(a.key).localeCompare(String(b.key)))
        .slice(-8);

      setData({
        status,
        months,
        vehicles: vehicleCount || 0,
        customers: customerCount || 0,
        recent: recentPage.items ?? [],
        jobs: (statusRows.rows ?? []).reduce((sum, r) => sum + r.count, 0),
        revenue: months.reduce((sum, m) => sum + m.revenue, 0),
        active: (status.scheduled || 0) + (status.in_progress || 0),
        unpaid: unpaidRows.rows?.[0]?.sum_total_cost || 0,
      });
    } catch (error) {
      setFailed(true);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const header = (
    <PageHeader
      eyebrow="Workshop overview"
      title="Today at the workshop"
      description="Service jobs, revenue and the jobs still on the floor."
      actions={
        <Button asChild variant="outline">
          <Link to="/services">Open service jobs</Link>
        </Button>
      }
    />
  );

  if (failed) {
    return (
      <div className="space-y-7">
        {header}
        <ErrorPanel message="The workshop numbers did not load." onRetry={load} />
      </div>
    );
  }

  if (!data) {
    return (
      <div className="space-y-7">
        {header}
        <div className="panel px-5 py-20 text-center text-sm text-muted-foreground">
          Loading workshop overview…
        </div>
      </div>
    );
  }

  if (data.jobs === 0) {
    return (
      <div className="space-y-7">
        {header}
        <EmptyState
          icon={Wrench}
          title="No service jobs yet"
          description="Add a customer and their vehicle, then log the first service job to see the numbers here."
        >
          <Button asChild>
            <Link to="/customers">Add a customer</Link>
          </Button>
        </EmptyState>
      </div>
    );
  }

  const donut = STATUS_META.filter((s) => data.status[s.key]).map((s) => ({
    name: s.label,
    value: data.status[s.key],
    fill: s.color,
  }));

  return (
    <div className="space-y-7">
      {header}

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="Service revenue"
          value={currency(data.revenue)}
          hint={`${data.jobs} jobs recorded`}
          icon={Wallet}
          tone="green"
        />
        <StatCard
          label="Jobs on the floor"
          value={data.active}
          hint="Scheduled or in progress"
          icon={Wrench}
          tone="amber"
        />
        <StatCard label="Vehicles" value={data.vehicles} icon={Car} tone="ink" />
        <StatCard label="Customers" value={data.customers} icon={Users} tone="blue" />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="panel p-5 lg:col-span-2">
          <div className="flex items-baseline justify-between">
            <h2 className="font-display text-base font-semibold tracking-tight">
              Service revenue by month
            </h2>
            <span className="text-xs text-muted-foreground">Last {data.months.length} months</span>
          </div>
          <div className="mt-5 h-[260px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data.months} margin={{ top: 4, right: 8, left: 0, bottom: 0 }}>
                <CartesianGrid vertical={false} stroke="hsl(var(--border))" strokeDasharray="3 3" />
                <XAxis
                  dataKey="month"
                  tickLine={false}
                  axisLine={false}
                  tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
                />
                <YAxis
                  tickLine={false}
                  axisLine={false}
                  width={58}
                  tickFormatter={compactCurrency}
                  tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
                />
                <Tooltip
                  contentStyle={tooltipStyle}
                  formatter={(value) => [currency(value), 'Revenue']}
                  cursor={{ fill: 'hsl(var(--secondary))' }}
                />
                <Bar dataKey="revenue" fill="hsl(var(--primary))" radius={[6, 6, 0, 0]} maxBarSize={46} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="panel p-5">
          <h2 className="font-display text-base font-semibold tracking-tight">Job status mix</h2>
          <div className="mt-4 h-[180px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={donut}
                  dataKey="value"
                  nameKey="name"
                  innerRadius={52}
                  outerRadius={78}
                  paddingAngle={3}
                  stroke="hsl(var(--card))"
                  strokeWidth={2}
                >
                  {donut.map((entry) => (
                    <Cell key={entry.name} fill={entry.fill} />
                  ))}
                </Pie>
                <Tooltip contentStyle={tooltipStyle} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <ul className="mt-4 space-y-2">
            {donut.map((entry) => (
              <li key={entry.name} className="flex items-center gap-2.5 text-sm">
                <span
                  className="h-2.5 w-2.5 rounded-full"
                  style={{ backgroundColor: entry.fill }}
                />
                <span className="text-muted-foreground">{entry.name}</span>
                <span className="ml-auto font-semibold text-foreground">{entry.value}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="panel lg:col-span-2">
          <div className="flex items-center justify-between border-b border-border px-5 py-4">
            <h2 className="font-display text-base font-semibold tracking-tight">Latest jobs</h2>
            <Link to="/services" className="text-xs font-semibold text-primary hover:underline">
              View all
            </Link>
          </div>
          <ul>
            {data.recent.map((job) => (
              <li
                key={job.id}
                className="flex items-center gap-4 border-b border-border px-5 py-3.5 last:border-0"
              >
                <div className="min-w-0 flex-1">
                  <Link
                    to={`/vehicles/${job.vehicle_id}`}
                    className="block truncate text-sm font-semibold text-foreground hover:text-primary"
                  >
                    {job.vehicle_label}
                  </Link>
                  <p className="truncate text-xs text-muted-foreground">
                    {job.service_type} · {formatDate(job.service_date)}
                  </p>
                </div>
                <StatusBadge status={job.status} />
                <span className="w-20 text-right font-display text-sm font-semibold">
                  {currency(job.total_cost)}
                </span>
              </li>
            ))}
          </ul>
        </div>

        <div className="panel flex flex-col p-5">
          <h2 className="font-display text-base font-semibold tracking-tight">Awaiting payment</h2>
          <p className="mt-3 font-display text-[28px] font-semibold leading-none text-foreground">
            {currency(data.unpaid)}
          </p>
          <p className="mt-2 text-xs text-muted-foreground">
            Invoices raised but not yet settled by customers.
          </p>
          <div className="mt-5 space-y-2.5 border-t border-border pt-4">
            {STATUS_META.slice(0, 3).map((s) => (
              <div key={s.key} className="flex items-center gap-2.5 text-sm">
                <span className="text-muted-foreground">{s.label}</span>
                <span className="ml-auto font-semibold">{data.status[s.key] || 0}</span>
              </div>
            ))}
          </div>
          <Button asChild variant="outline" className="mt-5 w-full">
            <Link to="/reports">Open reports</Link>
          </Button>
        </div>
      </div>
    </div>
  );
}