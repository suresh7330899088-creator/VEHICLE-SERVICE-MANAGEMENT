import React, { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle2, Pencil, Plus, Search, Trash2, Wrench } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import PageHeader from '@/components/PageHeader';
import StatusBadge from '@/components/StatusBadge';
import EmptyState from '@/components/EmptyState';
import ConfirmDialog from '@/components/ConfirmDialog';
import ServiceForm from '@/components/services/ServiceForm';
import useCurrentUser from '@/hooks/useCurrentUser';
import { SERVICE_TYPES } from '@/lib/serviceTypes';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { cn } from '@/lib/utils';
import { currency, formatDate } from '@/lib/format';

const STATUS_FILTERS = [
  { value: 'all', label: 'All' },
  { value: 'scheduled', label: 'Scheduled' },
  { value: 'in_progress', label: 'In progress' },
  { value: 'completed', label: 'Completed' },
  { value: 'cancelled', label: 'Cancelled' },
];

export default function Services() {
  const user = useCurrentUser();
  const isAdmin = user?.role === 'admin';

  const [status, setStatus] = useState('all');
  const [type, setType] = useState('all');
  const [search, setSearch] = useState('');
  const [term, setTerm] = useState('');
  const [rows, setRows] = useState([]);
  const [cursor, setCursor] = useState(null);
  const [hasMore, setHasMore] = useState(false);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setTerm(search.trim()), 300);
    return () => clearTimeout(t);
  }, [search]);

  const buildQuery = useCallback(() => {
    const query = {};
    if (status !== 'all') query.status = status;
    if (type !== 'all') query.service_type = type;
    if (term) {
      query.$or = [
        { vehicle_label: { $regex: term, $options: 'i' } },
        { customer_name: { $regex: term, $options: 'i' } },
        { technician: { $regex: term, $options: 'i' } },
      ];
    }
    return query;
  }, [status, type, term]);

  const load = useCallback(async () => {
    setLoading(true);
    const query = buildQuery();
    const [page, count] = await Promise.all([
      base44.entities.ServiceRecord.filter(query, { sort: '-service_date', limit: 50 }),
      base44.entities.ServiceRecord.count(query),
    ]);
    setRows(page.items ?? []);
    setCursor(page.next_cursor ?? null);
    setHasMore(Boolean(page.has_more));
    setTotal(count ?? 0);
    setLoading(false);
  }, [buildQuery]);

  const loadMore = async () => {
    const page = await base44.entities.ServiceRecord.filter(buildQuery(), {
      sort: '-service_date',
      limit: 50,
      cursor,
    });
    setRows((prev) => [...prev, ...(page.items ?? [])]);
    setCursor(page.next_cursor ?? null);
    setHasMore(Boolean(page.has_more));
  };

  useEffect(() => {
    load();
  }, [load]);

  const save = async (payload) => {
    setSaving(true);
    if (editing) await base44.entities.ServiceRecord.update(editing.id, payload);
    else await base44.entities.ServiceRecord.create(payload);
    setSaving(false);
    setDialogOpen(false);
    setEditing(null);
    load();
  };

  const markCompleted = async (record) => {
    await base44.entities.ServiceRecord.update(record.id, { status: 'completed' });
    load();
  };

  const remove = async (record) => {
    await base44.entities.ServiceRecord.delete(record.id);
    load();
  };

  return (
    <div className="space-y-7">
      <PageHeader
        eyebrow="Workshop floor"
        title="Service Jobs"
        description="Every job booked, in progress or closed — with the technician, date and cost."
        actions={
          <Button
            onClick={() => {
              setEditing(null);
              setDialogOpen(true);
            }}
          >
            <Plus className="h-4 w-4" /> New job
          </Button>
        }
      />

      <div className="panel flex flex-col gap-4 p-4 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex flex-wrap gap-1.5">
          {STATUS_FILTERS.map((f) => (
            <button
              key={f.value}
              type="button"
              onClick={() => setStatus(f.value)}
              className={cn(
                'rounded-full px-3.5 py-1.5 text-xs font-semibold transition-colors',
                status === f.value
                  ? 'bg-foreground text-background'
                  : 'bg-secondary text-muted-foreground hover:text-foreground',
              )}
            >
              {f.label}
            </button>
          ))}
        </div>

        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search vehicle, customer or technician"
              className="pl-9 sm:w-72"
            />
          </div>
          <Select value={type} onValueChange={setType}>
            <SelectTrigger className="sm:w-52">
              <SelectValue placeholder="All service types" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All service types</SelectItem>
              {SERVICE_TYPES.map((t) => (
                <SelectItem key={t} value={t}>
                  {t}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {loading ? (
        <div className="panel px-5 py-16 text-center text-sm text-muted-foreground">
          Loading jobs…
        </div>
      ) : rows.length === 0 ? (
        <EmptyState
          icon={Wrench}
          title="No service jobs match"
          description="Try a different status, service type or search term — or book a new job."
        >
          <Button
            variant="outline"
            onClick={() => {
              setStatus('all');
              setType('all');
              setSearch('');
            }}
          >
            Clear filters
          </Button>
        </EmptyState>
      ) : (
        <>
          <div className="panel overflow-hidden">
            <div className="hidden grid-cols-12 gap-4 border-b border-border px-5 py-3 text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground md:grid">
              <span className="md:col-span-2">Date</span>
              <span className="md:col-span-3">Vehicle</span>
              <span className="md:col-span-2">Service</span>
              <span className="md:col-span-2">Technician</span>
              <span className="md:col-span-1">Status</span>
              <span className="md:col-span-1 text-right">Total</span>
              <span className="md:col-span-1" />
            </div>

            {rows.map((record) => (
              <div
                key={record.id}
                className="grid grid-cols-1 gap-3 border-b border-border px-5 py-4 transition-colors last:border-0 hover:bg-secondary/40 md:grid-cols-12 md:items-center md:gap-4"
              >
                <span className="text-sm text-muted-foreground md:col-span-2">
                  {formatDate(record.service_date)}
                </span>
                <div className="min-w-0 md:col-span-3">
                  <Link
                    to={`/vehicles/${record.vehicle_id}`}
                    className="block truncate text-sm font-semibold text-foreground hover:text-primary"
                  >
                    {record.vehicle_label}
                  </Link>
                  <p className="truncate text-xs text-muted-foreground">{record.customer_name}</p>
                </div>
                <span className="text-sm text-foreground md:col-span-2">{record.service_type}</span>
                <span className="text-sm text-muted-foreground md:col-span-2">
                  {record.technician || 'Unassigned'}
                </span>
                <div className="md:col-span-1">
                  <StatusBadge status={record.status} />
                </div>
                <span className="font-display text-sm font-semibold text-foreground md:col-span-1 md:text-right">
                  {currency(record.total_cost)}
                </span>
                <div className="flex items-center gap-1 md:col-span-1 md:justify-end">
                  {record.status !== 'completed' && record.status !== 'cancelled' && (
                    <button
                      type="button"
                      title="Mark completed"
                      onClick={() => markCompleted(record)}
                      className="rounded-lg p-2 text-muted-foreground transition-colors hover:bg-emerald-50 hover:text-emerald-700"
                    >
                      <CheckCircle2 className="h-4 w-4" />
                    </button>
                  )}
                  <button
                    type="button"
                    title="Edit job"
                    onClick={() => {
                      setEditing(record);
                      setDialogOpen(true);
                    }}
                    className="rounded-lg p-2 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
                  >
                    <Pencil className="h-4 w-4" />
                  </button>
                  {isAdmin && (
                    <ConfirmDialog
                      title="Delete this service job?"
                      description="The job, its costs and its history entry will be removed permanently."
                      onConfirm={() => remove(record)}
                      trigger={
                        <button
                          type="button"
                          title="Delete job"
                          className="rounded-lg p-2 text-muted-foreground transition-colors hover:bg-rose-50 hover:text-rose-600"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      }
                    />
                  )}
                </div>
              </div>
            ))}
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3">
            <p className="text-xs text-muted-foreground">
              Showing {rows.length} of {total} matching {total === 1 ? 'job' : 'jobs'}
            </p>
            {hasMore && (
              <Button variant="outline" size="sm" onClick={loadMore}>
                Load more
              </Button>
            )}
          </div>
        </>
      )}

      <Dialog
        open={dialogOpen}
        onOpenChange={(open) => {
          setDialogOpen(open);
          if (!open) setEditing(null);
        }}
      >
        <DialogContent className="max-h-[90vh] max-w-2xl overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-display">
              {editing ? 'Edit service job' : 'New service job'}
            </DialogTitle>
            <DialogDescription>
              Record the vehicle, date, technician and the labour and parts costs.
            </DialogDescription>
          </DialogHeader>
          <ServiceForm
            key={editing?.id || 'new'}
            initial={editing}
            onSubmit={save}
            onCancel={() => {
              setDialogOpen(false);
              setEditing(null);
            }}
            saving={saving}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}