import React, { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Car, Gauge, Pencil, Plus, Search, Trash2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import PageHeader from '@/components/PageHeader';
import EmptyState from '@/components/EmptyState';
import ConfirmDialog from '@/components/ConfirmDialog';
import VehicleForm from '@/components/vehicles/VehicleForm';
import useCurrentUser from '@/hooks/useCurrentUser';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

export default function Vehicles() {
  const user = useCurrentUser();
  const isAdmin = user?.role === 'admin';

  const [search, setSearch] = useState('');
  const [term, setTerm] = useState('');
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setTerm(search.trim()), 300);
    return () => clearTimeout(t);
  }, [search]);

  const load = useCallback(async () => {
    setLoading(true);
    const query = {};
    if (term) {
      query.$or = [
        { license_plate: { $regex: term, $options: 'i' } },
        { make: { $regex: term, $options: 'i' } },
        { model: { $regex: term, $options: 'i' } },
        { customer_name: { $regex: term, $options: 'i' } },
      ];
    }
    const [page, count] = await Promise.all([
      base44.entities.Vehicle.filter(query, { sort: 'license_plate', limit: 50 }),
      base44.entities.Vehicle.count(query),
    ]);
    setRows(page.items ?? []);
    setTotal(count ?? 0);
    setLoading(false);
  }, [term]);

  useEffect(() => {
    load();
  }, [load]);

  const save = async (payload) => {
    setSaving(true);
    if (editing) await base44.entities.Vehicle.update(editing.id, payload);
    else await base44.entities.Vehicle.create(payload);
    setSaving(false);
    setDialogOpen(false);
    setEditing(null);
    load();
  };

  const remove = async (vehicle) => {
    await base44.entities.Vehicle.delete(vehicle.id);
    load();
  };

  return (
    <div className="space-y-7">
      <PageHeader
        eyebrow="Fleet register"
        title="Vehicles"
        description="Every vehicle the workshop looks after, with its owner and odometer."
        actions={
          <Button
            onClick={() => {
              setEditing(null);
              setDialogOpen(true);
            }}
          >
            <Plus className="h-4 w-4" /> Add vehicle
          </Button>
        }
      />

      <div className="panel flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative w-full sm:max-w-sm">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search plate, make, model or owner"
            className="pl-9"
          />
        </div>
        <p className="text-xs text-muted-foreground">
          {total} {total === 1 ? 'vehicle' : 'vehicles'} on record
        </p>
      </div>

      {loading ? (
        <div className="panel px-5 py-16 text-center text-sm text-muted-foreground">
          Loading vehicles…
        </div>
      ) : rows.length === 0 ? (
        <EmptyState
          icon={Car}
          title="No vehicles found"
          description="Add the first vehicle, or clear the search to see the whole register."
        >
          <Button variant="outline" onClick={() => setSearch('')}>
            Clear search
          </Button>
        </EmptyState>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {rows.map((vehicle) => (
            <div key={vehicle.id} className="panel flex flex-col p-5">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <Link
                    to={`/vehicles/${vehicle.id}`}
                    className="block font-display text-base font-semibold text-foreground hover:text-primary"
                  >
                    {vehicle.make} {vehicle.model}
                  </Link>
                  <span className="mt-1.5 inline-flex rounded-md bg-secondary px-2 py-1 font-mono text-[11px] font-semibold tracking-wide text-foreground">
                    {vehicle.license_plate}
                  </span>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    title="Edit vehicle"
                    onClick={() => {
                      setEditing(vehicle);
                      setDialogOpen(true);
                    }}
                    className="rounded-lg p-2 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
                  >
                    <Pencil className="h-4 w-4" />
                  </button>
                  {isAdmin && (
                    <ConfirmDialog
                      title="Remove this vehicle?"
                      description="The vehicle record is deleted. Its service jobs stay in the history."
                      confirmLabel="Remove vehicle"
                      onConfirm={() => remove(vehicle)}
                      trigger={
                        <button
                          type="button"
                          title="Delete vehicle"
                          className="rounded-lg p-2 text-muted-foreground transition-colors hover:bg-rose-50 hover:text-rose-600"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      }
                    />
                  )}
                </div>
              </div>

              <dl className="mt-4 grid grid-cols-2 gap-3 text-sm">
                <div>
                  <dt className="field-label">Owner</dt>
                  <dd className="truncate text-foreground">{vehicle.customer_name || '—'}</dd>
                </div>
                <div>
                  <dt className="field-label">Year</dt>
                  <dd className="text-foreground">{vehicle.year || '—'}</dd>
                </div>
                <div>
                  <dt className="field-label">Fuel</dt>
                  <dd className="capitalize text-foreground">{vehicle.fuel_type || '—'}</dd>
                </div>
                <div>
                  <dt className="field-label">Odometer</dt>
                  <dd className="inline-flex items-center gap-1.5 text-foreground">
                    <Gauge className="h-3.5 w-3.5 text-muted-foreground" />
                    {vehicle.mileage ? `${vehicle.mileage.toLocaleString('en-IN')} km` : '—'}
                  </dd>
                </div>
              </dl>
            </div>
          ))}
        </div>
      )}

      <Dialog
        open={dialogOpen}
        onOpenChange={(open) => {
          setDialogOpen(open);
          if (!open) setEditing(null);
        }}
      >
        <DialogContent className="max-h-[90vh] max-w-2xl overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-display">
              {editing ? 'Edit vehicle' : 'Add vehicle'}
            </DialogTitle>
            <DialogDescription>
              Link the vehicle to its owner so every service job stays in one history.
            </DialogDescription>
          </DialogHeader>
          <VehicleForm
            key={editing?.id || 'new'}
            initial={editing}
            onSubmit={save}
            onCancel={() => {
              setDialogOpen(false);
              setEditing(null);
            }}
            saving={saving}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}