import React, { useCallback, useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, CalendarClock, Gauge, Pencil, Plus, Trash2, User } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import StatCard from '@/components/StatCard';
import EmptyState from '@/components/EmptyState';
import ConfirmDialog from '@/components/ConfirmDialog';
import VehicleForm from '@/components/vehicles/VehicleForm';
import ServiceForm from '@/components/services/ServiceForm';
import ServiceHistoryList from '@/components/services/ServiceHistoryList';
import useCurrentUser from '@/hooks/useCurrentUser';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { currency, formatDate } from '@/lib/format';

export default function VehicleDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const user = useCurrentUser();
  const isAdmin = user?.role === 'admin';

  const [vehicle, setVehicle] = useState(null);
  const [owner, setOwner] = useState(null);
  const [jobs, setJobs] = useState([]);
  const [stats, setStats] = useState({ jobs: 0, total: 0 });
  const [loading, setLoading] = useState(true);
  const [missing, setMissing] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [jobOpen, setJobOpen] = useState(false);
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    let record;
    try {
      record = await base44.entities.Vehicle.get(id);
    } catch (error) {
      setMissing(true);
      setLoading(false);
      return;
    }
    setVehicle(record);
    setLoading(false);

    const [jobResult, statResult] = await Promise.allSettled([
      base44.entities.ServiceRecord.filter({ vehicle_id: id }, { sort: '-service_date', limit: 50 }),
      base44.entities.ServiceRecord.aggregate({ query: { vehicle_id: id }, sum: ['total_cost'] }),
    ]);
    if (jobResult.status === 'fulfilled') setJobs(jobResult.value.items ?? []);
    const row = statResult.status === 'fulfilled' ? statResult.value.rows?.[0] : null;
    setStats({ jobs: row?.count || 0, total: row?.sum_total_cost || 0 });

    if (record.customer_id) {
      base44.entities.Customer.get(record.customer_id).then(setOwner).catch(() => setOwner(null));
    }
  }, [id]);

  useEffect(() => {
    load();
  }, [load]);

  const saveVehicle = async (payload) => {
    setSaving(true);
    await base44.entities.Vehicle.update(id, payload);
    setSaving(false);
    setEditOpen(false);
    load();
  };

  const saveJob = async (payload) => {
    setSaving(true);
    await base44.entities.ServiceRecord.create(payload);
    setSaving(false);
    setJobOpen(false);
    load();
  };

  const remove = async () => {
    await base44.entities.Vehicle.delete(id);
    navigate('/vehicles');
  };

  if (loading) {
    return <div className="panel px-5 py-16 text-center text-sm text-muted-foreground">Loading vehicle…</div>;
  }

  if (missing || !vehicle) {
    return (
      <EmptyState icon={Gauge} title="Vehicle not found" description="This record may have been removed.">
        <Button variant="outline" onClick={() => navigate('/vehicles')}>
          Back to vehicles
        </Button>
      </EmptyState>
    );
  }

  const nextDue = jobs.find((j) => j.next_service_date)?.next_service_date;

  return (
    <div className="space-y-7">
      <Link
        to="/vehicles"
        className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.14em] text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="h-3.5 w-3.5" /> All vehicles
      </Link>

      <div className="panel p-6">
        <div className="flex flex-col gap-5 sm:flex-row sm:items-start sm:justify-between">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-primary">
              Vehicle record
            </p>
            <h1 className="mt-1.5 font-display text-2xl font-semibold tracking-tight">
              {vehicle.make} {vehicle.model}
            </h1>
            <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-2 text-sm text-muted-foreground">
              <span className="rounded-md bg-secondary px-2.5 py-1 font-mono text-xs font-semibold tracking-wide text-foreground">
                {vehicle.license_plate}
              </span>
              <span className="capitalize">
                {vehicle.fuel_type} · {vehicle.year || '—'} {vehicle.color ? `· ${vehicle.color}` : ''}
              </span>
              {vehicle.vin && <span className="font-mono text-xs">VIN {vehicle.vin}</span>}
            </div>
            {owner && (
              <Link
                to={`/customers/${owner.id}`}
                className="mt-4 inline-flex items-center gap-2 text-sm font-medium text-primary hover:underline"
              >
                <User className="h-4 w-4" /> {owner.full_name}
              </Link>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <Button
              onClick={() => setJobOpen(true)}
            >
              <Plus className="h-4 w-4" /> Log service
            </Button>
            <Button variant="outline" onClick={() => setEditOpen(true)}>
              <Pencil className="h-4 w-4" /> Edit
            </Button>
            {isAdmin && (
              <ConfirmDialog
                title="Remove this vehicle?"
                description="The vehicle record is deleted. Its service jobs stay in the history."
                confirmLabel="Remove vehicle"
                onConfirm={remove}
                trigger={
                  <Button variant="outline" className="text-rose-600 hover:text-rose-700">
                    <Trash2 className="h-4 w-4" /> Delete
                  </Button>
                }
              />
            )}
          </div>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="Odometer"
          value={vehicle.mileage ? `${vehicle.mileage.toLocaleString('en-IN')} km` : '—'}
          icon={Gauge}
          tone="ink"
        />
        <StatCard label="Service jobs" value={stats.jobs} tone="blue" />
        <StatCard label="Total service cost" value={currency(stats.total)} tone="green" />
        <StatCard
          label="Next service"
          value={nextDue ? formatDate(nextDue) : '—'}
          icon={CalendarClock}
          tone="amber"
        />
      </div>

      {vehicle.notes && (
        <p className="panel px-5 py-4 text-sm text-muted-foreground">{vehicle.notes}</p>
      )}

      <section className="space-y-4">
        <h2 className="font-display text-lg font-semibold tracking-tight">Service history</h2>
        <ServiceHistoryList records={jobs} />
      </section>

      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="max-h-[90vh] max-w-2xl overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-display">Edit vehicle</DialogTitle>
            <DialogDescription>Update the registration, odometer or owner.</DialogDescription>
          </DialogHeader>
          <VehicleForm
            initial={vehicle}
            onSubmit={saveVehicle}
            onCancel={() => setEditOpen(false)}
            saving={saving}
          />
        </DialogContent>
      </Dialog>

      <Dialog open={jobOpen} onOpenChange={setJobOpen}>
        <DialogContent className="max-h-[90vh] max-w-2xl overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-display">Log a service job</DialogTitle>
            <DialogDescription>
              Record this visit for {vehicle.make} {vehicle.model}.
            </DialogDescription>
          </DialogHeader>
          <ServiceForm
            vehicles={[vehicle]}
            lockedVehicleId={vehicle.id}
            onSubmit={saveJob}
            onCancel={() => setJobOpen(false)}
            saving={saving}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}