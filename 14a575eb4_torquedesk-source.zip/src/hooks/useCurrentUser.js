import { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';

export default function useCurrentUser() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    let active = true;
    base44.auth
      .me()
      .then((me) => active && setUser(me))
      .catch(() => active && setUser(null));
    return () => {
      active = false;
    };
  }, []);

  return user;
}