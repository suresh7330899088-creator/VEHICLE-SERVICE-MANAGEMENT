import React from 'react';
import { Link } from 'react-router-dom';
import { CalendarDays, Gauge, User } from 'lucide-react';
import StatusBadge from '@/components/StatusBadge';
import { currency, formatDate } from '@/lib/format';

export default function ServiceHistoryList({ records, showVehicle = false }) {
  if (!records?.length) {
    return (
      <p className="rounded-xl border border-dashed border-border px-4 py-10 text-center text-sm text-muted-foreground">
        No service jobs recorded yet.
      </p>
    );
  }

  return (
    <ol className="space-y-3">
      {records.map((record) => (
        <li key={record.id} className="rounded-2xl border border-border bg-card p-4 sm:p-5">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <p className="font-display text-sm font-semibold text-foreground">
                  {record.service_type}
                </p>
                <StatusBadge status={record.status} />
                {record.payment_status && <StatusBadge status={record.payment_status} />}
              </div>

              {showVehicle && (
                <Link
                  to={`/vehicles/${record.vehicle_id}`}
                  className="mt-1.5 inline-block text-xs font-semibold text-primary hover:underline"
                >
                  {record.vehicle_label}
                </Link>
              )}

              {record.description && (
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {record.description}
                </p>
              )}

              <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1.5 text-xs text-muted-foreground">
                <span className="inline-flex items-center gap-1.5">
                  <CalendarDays className="h-3.5 w-3.5" />
                  {formatDate(record.service_date)}
                </span>
                {record.technician && (
                  <span className="inline-flex items-center gap-1.5">
                    <User className="h-3.5 w-3.5" />
                    {record.technician}
                  </span>
                )}
                {record.mileage ? (
                  <span className="inline-flex items-center gap-1.5">
                    <Gauge className="h-3.5 w-3.5" />
                    {record.mileage.toLocaleString('en-IN')} km
                  </span>
                ) : null}
              </div>
            </div>

            <div className="text-right">
              <p className="font-display text-base font-semibold text-foreground">
                {currency(record.total_cost)}
              </p>
              <p className="mt-0.5 text-[11px] text-muted-foreground">
                Labour {currency(record.labor_cost)} · Parts {currency(record.parts_cost)}
              </p>
              {record.next_service_date && (
                <p className="mt-1 text-[11px] text-muted-foreground">
                  Next due {formatDate(record.next_service_date)}
                </p>
              )}
            </div>
          </div>
        </li>
      ))}
    </ol>
  );
}