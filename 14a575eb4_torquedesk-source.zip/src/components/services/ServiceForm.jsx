import React, { useEffect, useMemo, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import FormField from '@/components/FormField';
import { SERVICE_TYPES } from '@/lib/serviceTypes';
import { currency, today } from '@/lib/format';

const EMPTY = {
  vehicle_id: '',
  service_date: today(),
  service_type: 'General Service',
  status: 'scheduled',
  technician: '',
  mileage: '',
  labor_cost: '',
  parts_cost: '',
  payment_status: 'unpaid',
  description: '',
  next_service_date: '',
};

const toStr = (v) => (v === undefined || v === null ? '' : String(v));

export default function ServiceForm({ initial, vehicles: given, lockedVehicleId, onSubmit, onCancel, saving }) {
  const [fetched, setFetched] = useState([]);
  const [form, setForm] = useState(() => {
    const base = { ...EMPTY, ...(initial || {}) };
    return {
      ...base,
      vehicle_id: lockedVehicleId || base.vehicle_id || '',
      mileage: toStr(base.mileage),
      labor_cost: toStr(base.labor_cost),
      parts_cost: toStr(base.parts_cost),
    };
  });

  useEffect(() => {
    if (given) return;
    base44.entities.Vehicle.list({ sort: 'license_plate', limit: 200 }).then((res) =>
      setFetched(res.items ?? []),
    );
  }, [given]);

  const vehicles = given ?? fetched;
  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));
  const total = (Number(form.labor_cost) || 0) + (Number(form.parts_cost) || 0);
  const selected = useMemo(
    () => vehicles.find((v) => v.id === form.vehicle_id),
    [vehicles, form.vehicle_id],
  );

  const submit = (e) => {
    e.preventDefault();
    const labor = Number(form.labor_cost) || 0;
    const parts = Number(form.parts_cost) || 0;
    onSubmit({
      vehicle_id: form.vehicle_id,
      vehicle_label: selected ? `${selected.make} ${selected.model} · ${selected.license_plate}` : '',
      customer_id: selected?.customer_id || initial?.customer_id || '',
      customer_name: selected?.customer_name || initial?.customer_name || '',
      service_date: form.service_date,
      service_type: form.service_type,
      status: form.status,
      technician: form.technician,
      mileage: Number(form.mileage) || 0,
      labor_cost: labor,
      parts_cost: parts,
      total_cost: labor + parts,
      payment_status: form.payment_status,
      description: form.description,
      next_service_date: form.next_service_date || undefined,
    });
  };

  return (
    <form onSubmit={submit} className="space-y-5">
      <div className="grid gap-4 sm:grid-cols-2">
        <FormField label="Vehicle *" className="sm:col-span-2">
          <Select
            value={form.vehicle_id}
            onValueChange={(v) => setForm((f) => ({ ...f, vehicle_id: v }))}
            disabled={Boolean(lockedVehicleId)}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select a vehicle" />
            </SelectTrigger>
            <SelectContent>
              {vehicles.map((v) => (
                <SelectItem key={v.id} value={v.id}>
                  {v.license_plate} · {v.make} {v.model}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </FormField>

        <FormField label="Service date *">
          <Input type="date" value={form.service_date} onChange={set('service_date')} required />
        </FormField>
        <FormField label="Service type *">
          <Select value={form.service_type} onValueChange={(v) => setForm((f) => ({ ...f, service_type: v }))}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {SERVICE_TYPES.map((t) => (
                <SelectItem key={t} value={t}>
                  {t}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </FormField>

        <FormField label="Status">
          <Select value={form.status} onValueChange={(v) => setForm((f) => ({ ...f, status: v }))}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="scheduled">Scheduled</SelectItem>
              <SelectItem value="in_progress">In progress</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="cancelled">Cancelled</SelectItem>
            </SelectContent>
          </Select>
        </FormField>
        <FormField label="Technician">
          <Input value={form.technician} onChange={set('technician')} placeholder="Suresh Kumar" />
        </FormField>

        <FormField label="Odometer at service (km)">
          <Input type="number" value={form.mileage} onChange={set('mileage')} placeholder="44100" />
        </FormField>
        <FormField label="Payment">
          <Select value={form.payment_status} onValueChange={(v) => setForm((f) => ({ ...f, payment_status: v }))}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="unpaid">Unpaid</SelectItem>
              <SelectItem value="paid">Paid</SelectItem>
            </SelectContent>
          </Select>
        </FormField>

        <FormField label="Labour cost (₹)">
          <Input type="number" value={form.labor_cost} onChange={set('labor_cost')} placeholder="1200" />
        </FormField>
        <FormField label="Parts cost (₹)">
          <Input type="number" value={form.parts_cost} onChange={set('parts_cost')} placeholder="4300" />
        </FormField>

        <FormField label="Next service due">
          <Input type="date" value={form.next_service_date} onChange={set('next_service_date')} />
        </FormField>
        <div className="flex items-end">
          <div className="w-full rounded-xl bg-secondary px-4 py-2.5">
            <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
              Job total
            </p>
            <p className="font-display text-lg font-semibold text-foreground">{currency(total)}</p>
          </div>
        </div>
      </div>

      <FormField label="Work description">
        <Textarea rows={3} value={form.description} onChange={set('description')} placeholder="What was inspected, replaced or advised" />
      </FormField>

      <div className="flex justify-end gap-2 pt-1">
        <Button type="button" variant="ghost" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" disabled={saving || !form.vehicle_id}>
          {saving ? 'Saving…' : 'Save job'}
        </Button>
      </div>
    </form>
  );
}