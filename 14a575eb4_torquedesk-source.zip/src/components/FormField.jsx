import React from 'react';

export default function FormField({ label, hint, className, children }) {
  return (
    <div className={className}>
      <label className="field-label mb-1.5 block">{label}</label>
      {children}
      {hint && <p className="mt-1 text-[11px] text-muted-foreground">{hint}</p>}
    </div>
  );
}