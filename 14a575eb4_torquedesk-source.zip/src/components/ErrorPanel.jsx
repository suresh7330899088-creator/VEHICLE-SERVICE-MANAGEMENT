import React from 'react';
import { TriangleAlert } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function ErrorPanel({ message = 'We could not load this data just now.', onRetry }) {
  return (
    <div className="panel flex flex-col items-center justify-center px-6 py-16 text-center">
      <span className="grid h-12 w-12 place-items-center rounded-2xl bg-amber-100 text-amber-700">
        <TriangleAlert className="h-5 w-5" />
      </span>
      <p className="mt-4 font-display text-base font-semibold text-foreground">
        Something went wrong
      </p>
      <p className="mt-1 max-w-sm text-sm text-muted-foreground">{message}</p>
      {onRetry && (
        <Button variant="outline" className="mt-5" onClick={onRetry}>
          Try again
        </Button>
      )}
    </div>
  );
}