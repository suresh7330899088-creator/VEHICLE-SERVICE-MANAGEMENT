import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import FormField from '@/components/FormField';

const EMPTY = { full_name: '', phone: '', email: '', city: '', address: '', notes: '' };

export default function CustomerForm({ initial, onSubmit, onCancel, saving }) {
  const [form, setForm] = useState({ ...EMPTY, ...(initial || {}) });
  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  const submit = (e) => {
    e.preventDefault();
    onSubmit(Object.fromEntries(Object.keys(EMPTY).map((k) => [k, form[k] || ''])));
  };

  return (
    <form onSubmit={submit} className="space-y-5">
      <div className="grid gap-4 sm:grid-cols-2">
        <FormField label="Full name *">
          <Input value={form.full_name} onChange={set('full_name')} required placeholder="Aarav Sharma" />
        </FormField>
        <FormField label="Phone">
          <Input value={form.phone} onChange={set('phone')} placeholder="+91 98200 41122" />
        </FormField>
        <FormField label="Email">
          <Input type="email" value={form.email} onChange={set('email')} placeholder="name@email.com" />
        </FormField>
        <FormField label="City">
          <Input value={form.city} onChange={set('city')} placeholder="Mumbai" />
        </FormField>
      </div>
      <FormField label="Address">
        <Input value={form.address} onChange={set('address')} placeholder="Street, area, PIN" />
      </FormField>
      <FormField label="Notes">
        <Textarea rows={3} value={form.notes} onChange={set('notes')} placeholder="Anything the workshop should know" />
      </FormField>
      <div className="flex justify-end gap-2 pt-1">
        <Button type="button" variant="ghost" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" disabled={saving}>
          {saving ? 'Saving…' : 'Save customer'}
        </Button>
      </div>
    </form>
  );
}