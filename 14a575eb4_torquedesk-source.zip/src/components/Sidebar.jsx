import React from 'react';
import { Link, NavLink } from 'react-router-dom';
import { BarChart3, Car, LayoutDashboard, LogOut, Users, Wrench } from 'lucide-react';
import { cn } from '@/lib/utils';

const NAV = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/services', label: 'Service Jobs', icon: Wrench },
  { to: '/vehicles', label: 'Vehicles', icon: Car },
  { to: '/customers', label: 'Customers', icon: Users },
  { to: '/reports', label: 'Reports', icon: BarChart3 },
];

const initials = (name) =>
  (name || '')
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0])
    .join('')
    .toUpperCase() || 'WS';

export default function Sidebar({ user, onSignOut, onNavigate }) {
  return (
    <div className="flex h-full w-[264px] flex-col bg-sidebar text-sidebar-foreground">
      <Link to="/" onClick={onNavigate} className="flex items-center gap-3 px-5 pb-6 pt-7">
        <span className="grid h-10 w-10 place-items-center rounded-xl bg-primary font-display text-lg font-bold text-primary-foreground shadow-lg shadow-primary/25">
          T
        </span>
        <span className="leading-tight">
          <span className="block font-display text-base font-semibold tracking-tight text-white">
            TorqueDesk
          </span>
          <span className="block text-[10px] font-medium uppercase tracking-[0.2em] text-white/40">
            Workshop Console
          </span>
        </span>
      </Link>

      <nav className="flex flex-1 flex-col gap-1 px-3">
        {NAV.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            onClick={onNavigate}
            className={({ isActive }) =>
              cn(
                'relative flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium transition-colors',
                isActive
                  ? 'bg-white/10 text-white'
                  : 'text-white/55 hover:bg-white/5 hover:text-white/90',
              )
            }
          >
            {({ isActive }) => (
              <>
                <span
                  className={cn(
                    'absolute left-0 top-1/2 h-5 w-[3px] -translate-y-1/2 rounded-full bg-primary transition-opacity',
                    isActive ? 'opacity-100' : 'opacity-0',
                  )}
                />
                <item.icon className="h-4 w-4 shrink-0" strokeWidth={2} />
                {item.label}
              </>
            )}
          </NavLink>
        ))}
      </nav>

      <div className="mt-6 border-t border-white/10 p-4">
        <div className="flex items-center gap-3">
          <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-white/10 text-xs font-semibold text-white">
            {initials(user?.full_name)}
          </span>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-medium text-white">
              {user?.full_name || 'Workshop user'}
            </p>
            <p className="truncate text-[10px] font-medium uppercase tracking-[0.16em] text-white/40">
              {user?.role === 'admin' ? 'Manager' : 'Service advisor'}
            </p>
          </div>
          <button
            type="button"
            onClick={onSignOut}
            title="Sign out"
            className="rounded-lg p-2 text-white/45 transition-colors hover:bg-white/10 hover:text-white"
          >
            <LogOut className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
}