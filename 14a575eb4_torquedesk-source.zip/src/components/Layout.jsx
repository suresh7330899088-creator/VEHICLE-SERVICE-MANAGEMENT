import React, { useEffect, useState } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import Sidebar from '@/components/Sidebar';

export default function Layout() {
  const [user, setUser] = useState(null);
  const [drawer, setDrawer] = useState(false);
  const location = useLocation();

  useEffect(() => {
    base44.auth
      .me()
      .then(setUser)
      .catch(() => setUser(null));
  }, []);

  useEffect(() => {
    setDrawer(false);
    window.scrollTo({ top: 0 });
  }, [location.pathname]);

  const signOut = async () => {
    await base44.auth.logout('/login');
  };

  return (
    <div className="min-h-screen bg-background">
      <div
        aria-hidden
        className="pointer-events-none fixed inset-0 -z-10 bg-[radial-gradient(120%_80%_at_100%_0%,hsl(var(--primary)/0.07),transparent_60%)]"
      />

      <aside className="fixed inset-y-0 left-0 z-40 hidden lg:block">
        <Sidebar user={user} onSignOut={signOut} />
      </aside>

      {drawer && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <button
            type="button"
            aria-label="Close menu"
            className="absolute inset-0 bg-black/50 backdrop-blur-sm"
            onClick={() => setDrawer(false)}
          />
          <div className="absolute inset-y-0 left-0 shadow-2xl">
            <Sidebar user={user} onSignOut={signOut} onNavigate={() => setDrawer(false)} />
            <button
              type="button"
              onClick={() => setDrawer(false)}
              className="absolute -right-11 top-4 rounded-full bg-white/10 p-2 text-white backdrop-blur"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}

      <div className="lg:pl-[264px]">
        <header className="sticky top-0 z-30 flex items-center gap-3 border-b border-border bg-background/85 px-4 py-3 backdrop-blur-md lg:hidden">
          <button
            type="button"
            onClick={() => setDrawer(true)}
            className="rounded-lg border border-border bg-card p-2 text-foreground"
          >
            <Menu className="h-4 w-4" />
          </button>
          <span className="font-display text-sm font-semibold tracking-tight">TorqueDesk</span>
        </header>

        <main className="mx-auto w-full max-w-[1180px] px-4 py-7 sm:px-6 lg:px-10 lg:py-10">
          <Outlet />
        </main>
      </div>
    </div>
  );
}