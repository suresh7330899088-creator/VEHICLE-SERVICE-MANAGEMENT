import React from 'react';
import { cn } from '@/lib/utils';

const TONES = {
  primary: 'bg-primary/10 text-primary',
  ink: 'bg-foreground/8 text-foreground',
  blue: 'bg-sky-100/70 text-sky-700',
  green: 'bg-emerald-100/70 text-emerald-700',
  amber: 'bg-amber-100/70 text-amber-700',
};

export default function StatCard({ label, value, hint, icon: Icon, tone = 'primary' }) {
  return (
    <div className="panel group p-5 transition-shadow hover:shadow-[0_1px_2px_rgba(16,20,28,0.04),0_18px_40px_-26px_rgba(16,20,28,0.4)]">
      <div className="flex items-start justify-between gap-3">
        <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">
          {label}
        </p>
        {Icon && (
          <span className={cn('grid h-9 w-9 place-items-center rounded-xl', TONES[tone])}>
            <Icon className="h-4 w-4" strokeWidth={2} />
          </span>
        )}
      </div>
      <p className="mt-4 font-display text-[26px] font-semibold leading-none tracking-tight text-foreground">
        {value}
      </p>
      {hint && <p className="mt-2 text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}