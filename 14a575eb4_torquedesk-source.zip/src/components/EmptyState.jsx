import React from 'react';

export default function EmptyState({ icon: Icon, title, description, children }) {
  return (
    <div className="panel flex flex-col items-center justify-center px-6 py-14 text-center">
      {Icon && (
        <span className="grid h-12 w-12 place-items-center rounded-2xl bg-secondary text-muted-foreground">
          <Icon className="h-5 w-5" />
        </span>
      )}
      <p className="mt-4 font-display text-base font-semibold text-foreground">{title}</p>
      {description && <p className="mt-1 max-w-sm text-sm text-muted-foreground">{description}</p>}
      {children && <div className="mt-5 flex items-center gap-2">{children}</div>}
    </div>
  );
}