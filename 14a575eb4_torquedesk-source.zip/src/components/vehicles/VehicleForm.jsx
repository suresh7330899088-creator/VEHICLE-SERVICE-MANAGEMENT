import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import FormField from '@/components/FormField';

const EMPTY = {
  customer_id: '',
  make: '',
  model: '',
  year: '',
  license_plate: '',
  vin: '',
  color: '',
  mileage: '',
  fuel_type: 'petrol',
  notes: '',
};

const FUELS = ['petrol', 'diesel', 'electric', 'hybrid', 'cng'];

const toStr = (v) => (v === undefined || v === null ? '' : String(v));

export default function VehicleForm({ initial, onSubmit, onCancel, saving }) {
  const [customers, setCustomers] = useState([]);
  const [form, setForm] = useState(() => {
    const base = { ...EMPTY, ...(initial || {}) };
    return {
      ...base,
      year: toStr(base.year),
      mileage: toStr(base.mileage),
    };
  });

  useEffect(() => {
    base44.entities.Customer.list({ sort: 'full_name', limit: 200 }).then((res) =>
      setCustomers(res.items ?? []),
    );
  }, []);

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  const submit = (e) => {
    e.preventDefault();
    const owner = customers.find((c) => c.id === form.customer_id);
    onSubmit({
      customer_id: form.customer_id,
      customer_name: owner?.full_name || form.customer_name || '',
      make: form.make,
      model: form.model,
      year: Number(form.year) || 0,
      license_plate: form.license_plate,
      vin: form.vin,
      color: form.color,
      mileage: Number(form.mileage) || 0,
      fuel_type: form.fuel_type,
      notes: form.notes,
    });
  };

  return (
    <form onSubmit={submit} className="space-y-5">
      <FormField label="Owner *">
        <Select value={form.customer_id} onValueChange={(v) => setForm((f) => ({ ...f, customer_id: v }))}>
          <SelectTrigger>
            <SelectValue placeholder="Select a customer" />
          </SelectTrigger>
          <SelectContent>
            {customers.map((c) => (
              <SelectItem key={c.id} value={c.id}>
                {c.full_name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </FormField>

      <div className="grid gap-4 sm:grid-cols-2">
        <FormField label="Make *">
          <Input value={form.make} onChange={set('make')} required placeholder="Hyundai" />
        </FormField>
        <FormField label="Model *">
          <Input value={form.model} onChange={set('model')} required placeholder="Creta SX" />
        </FormField>
        <FormField label="Registration plate *">
          <Input value={form.license_plate} onChange={set('license_plate')} required placeholder="KA-05-MJ-8890" />
        </FormField>
        <FormField label="Fuel type">
          <Select value={form.fuel_type} onValueChange={(v) => setForm((f) => ({ ...f, fuel_type: v }))}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {FUELS.map((f) => (
                <SelectItem key={f} value={f}>
                  {f.charAt(0).toUpperCase() + f.slice(1)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </FormField>
        <FormField label="Year">
          <Input type="number" value={form.year} onChange={set('year')} placeholder="2021" />
        </FormField>
        <FormField label="Odometer (km)">
          <Input type="number" value={form.mileage} onChange={set('mileage')} placeholder="31650" />
        </FormField>
        <FormField label="Colour">
          <Input value={form.color} onChange={set('color')} placeholder="White" />
        </FormField>
        <FormField label="VIN / chassis">
          <Input value={form.vin} onChange={set('vin')} />
        </FormField>
      </div>

      <FormField label="Notes">
        <Textarea rows={2} value={form.notes} onChange={set('notes')} />
      </FormField>

      <div className="flex justify-end gap-2 pt-1">
        <Button type="button" variant="ghost" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" disabled={saving || !form.customer_id}>
          {saving ? 'Saving…' : 'Save vehicle'}
        </Button>
      </div>
    </form>
  );
}